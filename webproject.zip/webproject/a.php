
<form method="POST" action="searchprofile.php">
    <input type="text" name="search"/>
    <input type="submit" name="submit" value="search">
</form>
<html>
<body>
<a href="logout.php"><button class="button button1">Log out</button></a>
<?php

session_start();
if($_SESSION["flag"]=="ok"){
	echo "Picture: <br><br>".'<img src="uploads/'.$_SESSION["img"].
     '" style="width:300px;height:300px;">'."</p><br>";
	 echo "<br><h1>Welcome ".$_SESSION["name"]."</h1><br><br>";
     echo "<div>Name: ".$_SESSION["name"]."<br><br>";
     echo "Description: ".$_SESSION["description"]."<br><br>";
     echo "Email: ".$_SESSION["email"]."<br><br>";
     echo "Gender: ".$_SESSION["gender"]."<br><br>";
	 echo "level: ".$_SESSION["level"]."<br><br>";
	 echo "academic: ".$_SESSION["academic"]."<br><br>";

	 ?>

	 <?php
}
else{
	header("Location:project.html");
}
?>
</div>
</body>
</html>

<html>
<head>
<style>
  body
    {
     background-image:url("profile.jpg");
     background-position:right-top;
     background-repeat:no-repeat;
     color: #e7e7e7;     
    }
	input
    {
     width:250px;
     height:30px;
	}
 input[type="Log Out"]
    {
     background: #3399ff;
     border: 0;
     width: 250px;
     height: 40px;
     border-radius: 3px;
     color: white;
    }

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	position: absolute;
	top:3%;
	left:90%;
}
.button2 {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	position: absolute;
	top:3%;
	left:80%;
}

</style><center>
</head>
<body>  
</body>
</html>