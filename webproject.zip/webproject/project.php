<!DOCTYPE html>+
 <html>
 <style>
 .login
    {
	 color: blue;
	 max-width: 300px;
	 margin:auto;
	 border: 2px solid black;
	 padding:20px 30px;
	 background: rgba(0,0,0,0.5);
	
     position: absolute;
     top:15%;
     left:40%;
	 border-radius:5px;
	}
	
 h1
    {
	 font-size: 150%;
     color:white;
	}

 h2
    {
	 font-size: 100%;
     color:white;
	}

 h3
    {
	 font-size: 100%;
     color:white;
	}
h4
    {
	 font-size: 150%;
     color:white;
	}	
a
    {
	 color:white;
	}
	
 body
    {
	 background-image:url("backlogin.jpg");
	 background-position:right-top;
	 background-repeat:no-repeat;
	 background-size:cover;
	 background-attachment:fixed;
	 color: #e7e7e7; 	 
    }
 
 input
    {
     width:250px;
     height:30px;
	}
 input[type="submit"]
    {
     background: #3399ff;
     border: 0;
     width: 250px;
     height: 40px;
     border-radius: 3px;
     color: white;
    }

	
</style><center>

<body>

<div class="login">

<form  action="LoginCheck.php" method="post"> 
<h1>LOGIN FORM</h1>
<h2>Name:</h2><input type="text" name="name" placeholder="Name">
<h3>Password:</h3><input type="password" name="password" placeholder="Password"><br><br>
<input type="submit" name="submit">
</form>

</div>
</body>
</html> 