<?php
include ('connect.php');
include ('function.php');

?>

<?php



if(isset($_FILES['image']) && isset($_POST['name']) &&isset($_POST['email']) && isset($_POST['password']) &&
    isset($_POST['gender']) && isset($_POST['des'])&&isset($_POST['level'])&&$_POST['des_aca'])
{

    $file_name = $_FILES['image']['name'];

    $level = test_input($_POST['level']);
    $des_aca = test_input($_POST['des_aca']);

    $name = test_input($_POST['name']);
    $email = test_input($_POST['email']);
    $password = test_input($_POST['password']);
    $gender = test_input($_POST['gender']);
    $des = test_input($_POST['des']);


    $slq = "insert into project(name,email,password,description,gender,img,academic,level)VALUES ('$name','$email','$password','$des',
'$gender','$file_name','$des_aca','$level')";

    $insert = $connect->query($slq);//if slq work then insert will be 1 otherwise 0
    
    $errors= array();

    $file_size = $_FILES['image']['size'];//determine file size format
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_type = $_FILES['image']['type'];//determine type
    $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));//afterfilename.

    $expensions= array("jpeg","jpg","png");

    if(in_array($file_ext,$expensions)=== false){
        $errors[]="extension not allowed, please choose a JPEG or PNG file.";
    }

    if($file_size > 512097152) {
        $errors[]='File size must be excately 5 MB';
    }

    if(empty($errors)==true) {
        move_uploaded_file($file_tmp,"uploads/".$file_name);//save file in uploads/ folder
//        echo "Success";
    }else{
        print_r($errors);//show error msg
    }
    if ($insert){
        header('Location:project.php');//back to login page
    }




}




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="bootstrap-3.3.7-dist/css/bootstrap.min.css">
    <meta charset="UTF-8">
    <title>Title</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="main_form_wrap">
    <div class="container form_start">

        <div class="row ">



            <form class="form-horizontal col-sm-5 col-sm-offset-3 col-md-offset-4  col-lg-offset-4 form_style" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"  enctype = "multipart/form-data">
                <div class="form-group">
                    <label for="name">Full Name</label>

                    <input class="form-control input-md" placeholder="Enter your name" id="name" name="name" type="text">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>

                    <input class="form-control input-md" placeholder="Enter your Email" id="email" name="email" type="email">
                </div>
                <div class="form-group">
                    <label for="name">Password</label>

                    <input class="form-control input-md" placeholder="Enter your Password" id="password" name="password" type="password">
                </div>
                <div class="form-group">
                    <label for="text-area">Description</label>

                    <textarea  class="form-control input-md " name = "des" id="text-area" placeholder="Describe yourself..."></textarea>
                </div>
                <div class="form-group">
                    <label for="text-area">Academic Description</label>

                    <textarea  class="form-control input-md " name = "des_aca" id="text-area" placeholder="Describe yourself..."></textarea>
                </div>


                <div class="form-group">

                    <label class="radio-inline"><input type="radio" name="gender" value="male" checked>Male</label>
                    <label class="radio-inline"><input type="radio" name="gender" value="Female">Female</label>
                </div>

                <div class="form-group">

                    <p>Level</p>

                    <label class="radio-inline"><input type="radio" name="level" value="author" checked>Author</label>
                    <label class="radio-inline"><input type="radio" name="level" value="user">User</label>
                </div>




               <div class="form-group">
                   <label for="img">Image</label>
                   <input class="form-control input-md" name="image" id="img" type="file">
               </div>

                <div class="form-group text-center input-group-btn">
                    <input type="submit" class="form-control btn btn-block" name="submit" value="Register" >

                </div>


            </form>
        </div>

    </div>

</div>





<script src="bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>
<script src="jquery/jquery-3.1.1.min.js"> </script>

</body>
</html>