 <?php 
/**
 * Created by PhpStorm.
 * User: Shahidul Islam
 * Date: 8/18/2017
 * Time: 12:56 PM
 * Verified Licence Credentials
 */
  ?>
 <form method="POST" action="searchprofile.php">
    <input type="text" name="search"/>
    <input type="submit" name="submit" value="search">
</form>