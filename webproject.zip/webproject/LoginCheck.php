<pre>
<?php


session_start();
$_SESSION["flag"]="";


if(strlen($_REQUEST["name"])==0 && strlen($_REQUEST["password"])==0)
{
	header("Location:project.php");
}

else
{
	include("database.php");
	
	$sql="select * from project where name='".$_REQUEST['name']."'";
	echo $sql."<br/>";
	$jsonData= getJSONFromDB($sql);
	
	$jsonData = json_decode($jsonData, true);
	//print_r($GLOBALS);
	//echo $jsonData[0]["name"];
	//echo $jsonData[0]["Password"];
	
	if($jsonData[0]["password"]==($_REQUEST["password"]))
	{
	  $_SESSION["name"] = $jsonData[0]["name"];
	  $_SESSION["description"] = $jsonData[0]["description"];
	  $_SESSION["img"] = $jsonData[0]["img"];
	  $_SESSION["email"] = $jsonData[0]["email"];
	  $_SESSION["academic"] = $jsonData[0]["academic"];
	  $_SESSION["gender"] = $jsonData[0]["gender"];
	  $_SESSION["level"]= $jsonData[0]["level"];
	  //$_SESSION["password"]= $jsonData[0]["password"];
	  //$_SESSION["dateOfBirth"]= $jsonData[0]["DOB"];
	  
	  $_SESSION["flag"]="ok";
		header("Location:User.php");
	}
	else{
		header("Location:project.php");
	}
	
}

?>

</pre>