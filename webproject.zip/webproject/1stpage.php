<!DOCTYPE html>
<html>
<head>
<style>
span
{
font-family:"Times New Roman",Times,serif;
font-size:2.2em;
font-width:bold;
}
h2{
    text-transform: capitalize;
	color:rgb(255,255,255);
	font-family:"Times New Roman",Times,serif;
	top:25%;
    left:30%;
	font-size:3.5em;
	position: absolute;
}
body
{
     background-image:url("startpage.jpg");
	 background-position:right-top;
	 background-repeat:no-repeat;
	 background-size:cover;
	 background-attachment:fixed;
	 color: #e7e7e7;
}
.button {
   display: inline-block;
   border-radius: 4px;
   background-color: rgb(0,128,255);
   border-style: solid;
   color: blue;
   text-align: center;
   width: 300px;
   margin:auto;
   border: 2px solid ;
   padding:20px 30px;
   transition: all 0.5s;
   cursor: pointer;
   margin: 5px;
   position: absolute;
   top:55%;
   left:40%;
   height:80px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style><center>
</head>
<body>

<h2>A Place For Reseracher</h2>

<a href="2ndpage.php"><button class="button" style="vertical-align:middle"><span>GET STARTED </span></button></a> 

</body>
</html>
