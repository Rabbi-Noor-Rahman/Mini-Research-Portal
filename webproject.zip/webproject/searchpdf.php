<?php
	$textsearch = $_REQUEST['searchpdf'];
	$pdfsearch = $textsearch . ".pdf";
	include ("db.php");
	$sql = "SELECT * FROM upload where upload = '$pdfsearch'";
	$result = mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($result);
?>


<iframe src="uploads/<?php echo $row['upload'] ?>" width="100%" style="height: 100%"></iframe>

