<?php
$host = "localhost";
$username = "root";
$password = "";
$database ="project";

$connect = new mysqli($host,$username,$password,$database);
?>
