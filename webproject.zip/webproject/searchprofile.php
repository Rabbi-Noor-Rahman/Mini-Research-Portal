<?php
	$textsearch = $_REQUEST['search'];
	include ("db.php");//database connection
	$sql = "SELECT * FROM project where name = '$textsearch' OR email = '$textsearch'";
	$result = mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($result);
?>
<html>
<style>
  body
    {
     background-image:url("profile.jpg");
     background-position:right-top;
     background-repeat:no-repeat;
     color: #e7e7e7;     
    }
	.search{
		font-family:"Times New Roman",Times,serif;
        font-size:1.5em;
        font-width:bold;
	}
</style>
<body>
<div class="search">
<h1>Search Result :</h1>

		<Profile Image:<br>
		 <img src="uploads/<?php echo $row['img']; ?>" alt="profile picture" width="300px" height="250px"><br><br>
	
	     Name : <?php echo $row['name']; ?><br>
	
	     Email : <?php echo $row['email']; ?><br>
         Description : <?php echo $row['description']; ?><br>

         Gender :<?php echo $row['gender']; ?><br>
         Academic :<?php echo $row['academic']; ?><br>
         Level : <?php echo $row['level']; ?><br>

</div>
</body>
</html>