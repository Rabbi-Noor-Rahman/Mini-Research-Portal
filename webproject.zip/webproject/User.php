
<html>
<style>
 input
    {
     width:100px;
     height:50px;
	position:absolute;
	top:5%;
	left:47%;
	 
	}
 input[type="submit"]
    {
     background: #3399ff;
     border: 0;
     width: 150px;
     height: 40px;
     border-radius: 3px;
     color: white;
	 position:absolute;
	top:4%;
	left:67%;
    }

</style>
<body>
<div class="search">
<form method="POST" action="searchprofile.php">
    <input type="text" name="search" placeholder="Enter name or email"/>
    <input type="submit" name="submit" value="search">
</form>
</div>
</body>
</html>


<html>
<body>
<a href="logout.php"><button class="button button1">Log out</button></a>
<a href="upload1.php"><button class="button button2">Upload</button></a>
<?php

session_start();
if($_SESSION["flag"]=="ok"){
	echo "Picture: <br><br>".'<img src="uploads/'.$_SESSION["img"].
     '" style="width:300px;height:300px;">'."</p><br>";
	 echo "<br><h1>Welcome ".$_SESSION["name"]."</h1><br><br>";
     echo "<div>Name: ".$_SESSION["name"]."<br><br>";
     echo "Description: ".$_SESSION["description"]."<br><br>";
     echo "Email: ".$_SESSION["email"]."<br><br>";
     echo "Gender: ".$_SESSION["gender"]."<br><br>";
	 echo "level: ".$_SESSION["level"]."<br><br>";
	 echo "academic: ".$_SESSION["academic"]."<br><br>";

	 ?>

	 <?php
}
else{
	header("Location:project.html");
}
?>
</div>
</body>
</html>

<html>
<head>
<style>
 .searchpdf
    {
     width:100px;
     height:50px;
	 position:absolute;
	 top:11%;
	 left:43.5%;
	 
	}
 .pdf
    {
     background: #3399ff;
     border: 0;
     width: 15px;
     height: 40px;
     border-radius: 3px;
     color: white;
	 position:absolute;
	 top:8%;
	 left:318%;
    }
  body
    {
     background-image:url("profile.jpg");
     background-position:right-top;
     background-repeat:no-repeat;
     color: #e7e7e7;     
    }
	input
    {
     width:250px;
     height:30px;
	}
 input[type="Log Out"]
    {
     background: #3399ff;
     border: 0;
     width: 250px;
     height: 40px;
     border-radius: 3px;
     color: white;
    }

.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	position: absolute;
	top:3%;
	left:90%;
}
.button2 {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	position: absolute;
	top:3%;
	left:80%;
}

</style>
</head>
<body>  
<div class="searchpdf">
<form method="POST" action="searchpdf.php">
    <input type="text" name="searchpdf" placeholder="Enter pdf name"/>
	<div class="pdf">
    <input type="submit" name="submit" value="search pdf"/>
	</div>
</form>
</div>
</body>
</html>