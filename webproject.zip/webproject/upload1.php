<?php
include ('connect.php');
include ('function.php');
?>
<?php
if(isset($_FILES['upload'])) {
    $file_name = $_FILES['upload']['name'];
    $slq = "insert into upload(upload)VALUE ('$file_name')";
    $insert = $connect->query($slq);

    $errors = array();

    $file_size = $_FILES['upload']['size'];
    $file_tmp = $_FILES['upload']['tmp_name'];
    $file_type = $_FILES['upload']['type'];
    $file_ext = strtolower(end(explode('.', $_FILES['upload']['name'])));

   $expensions = array("jpeg", "jpg", "png", "pdf");

    if (in_array($file_ext, $expensions) === false) {
        $errors[] = "extension not allowed, please choose a JPEG or PNG file.";
    }

    if ($file_size > 122097152) {
        $errors[] = 'File size must be excately 4 MB';
    }

    if (empty($errors) == true) {
        move_uploaded_file($file_tmp, "uploads/" . $file_name);
//        echo "Success";
    } else {
        print_r($errors);
		
    }if ($insert){
        header('Location:User.php');
    }
}
?>
<html>
<head>

</head>
<body>

<form method="POST" action="upload1.php" enctype = "multipart/form-data">
    <input type="file" name="upload"/>
    <input type="submit" name="submit" value="upload"/>
</form>
</body>
</html>